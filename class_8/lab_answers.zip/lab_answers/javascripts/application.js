$(document).ready( function() {
  $('.first_draggable').draggable({
    appendTo: "body"
  })

  $('.second_draggable').draggable({
    appendTo: ".orange_background",
    containment: ".orange_background"
  })

  $('.third_draggable').draggable({
    appendTo: "blue_box",
    scope: "blue_drag",
    drag: function(event, ui){
      $('.blue_box').removeClass("highlight").html("Drop it in here, just touching.");
    }
  })

  $('.blue_box').droppable({
    scope: "blue_drag",
    tolerance: "touch",
    drop: function( event, ui ) {
      console.log("sup");
      $( this ).addClass( "highlight" ).html( "Dropped!" );
		}
  })
  
  $('.fourth_draggable').draggable({
    appendTo: "red_box",
    scope: "red_drag",
    drag: function(event, ui){
      $('.red_box').removeClass("highlight").html("Drop it in here, fully inside.");
    }
  })

  $('.red_box').droppable({
    scope: "red_drag",
    tolerance: "fit",
    drop: function( event, ui ) {
      console.log("sup");
      $( this ).addClass( "highlight" ).html( "Dropped!" );
		}
  })  
  
  $("ul.dates_sortable").sortable()
})