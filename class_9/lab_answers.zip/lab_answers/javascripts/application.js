$(document).ready( function() {
  $('.change_ajax').tap( function() {
    $.mobile.defaultPageTransition = $(this).attr('transition')    
  })
})
