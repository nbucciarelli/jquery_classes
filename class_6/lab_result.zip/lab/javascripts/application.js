$(document).ready( function() {
  $('.information').qtip({
    content: 'This is an example',
    show: 'mouseover',
    hide: 'mouseout',
    position: {
       corner: {
          target: 'topRight',
          tooltip: 'topLeft'
       }
    },
    style: {
      name: 'cream'
    }
  })

  $('.address_table').tablesorter({sortList: [[0,0], [1,0]]})
  
  $('.football_team').chosen()
  
})